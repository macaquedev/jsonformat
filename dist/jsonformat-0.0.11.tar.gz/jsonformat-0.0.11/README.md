jsonformat
==========

A simple JSON pretty formatter with no external dependencies.

To install, simply type:

    pip install jsonformat

To format a json file, type this:

    jsonformat <filename> [-q]

The filename argument is mandatory. The -q argument switches off console output.